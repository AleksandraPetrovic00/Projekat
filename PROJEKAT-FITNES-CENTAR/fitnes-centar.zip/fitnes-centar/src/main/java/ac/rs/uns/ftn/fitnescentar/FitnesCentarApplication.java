package ac.rs.uns.ftn.fitnescentar;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FitnesCentarApplication {

	public static void main(String[] args) {
		SpringApplication.run(FitnesCentarApplication.class, args);
	}

}
